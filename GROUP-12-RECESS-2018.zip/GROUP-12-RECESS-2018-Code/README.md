# GROUP-12-RECESS-2018
This repository is for recess work 2018.
#### GROUP MEMBERS DETAILS (CONTRIBUTORS)

| NAMES         | REGISTRATION No.| STUDENT NO.|EMAIL  |
| ------------- |:-------------:| -----:| -----:|
| ISABIRYE TAIBU | 16/U/20495 | 216022278|isabiryetai645@gmail.com |
|NABUUFU ERETH   | 16/U/8227/EVE|  216009341|luckybrave12@gmail.com|
| NAKIRANDA PROSCOVIA | 16/U/8785/PS| 216002865|nakirandaproscovia@gmail.com |
|KANDOLE LAILA | 12/U/6171/PS|  212011932|courtneyspacy@gmail.com|

